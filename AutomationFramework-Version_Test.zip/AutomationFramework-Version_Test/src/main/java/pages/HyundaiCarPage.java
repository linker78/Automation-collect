package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import base.BasePage;

public class HyundaiCarPage  extends BasePage{

	public HyundaiCarPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	

}
